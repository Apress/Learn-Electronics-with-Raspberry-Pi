#!/usr/bin/python3
from traincontrol import *

train_set_speed(0.3)